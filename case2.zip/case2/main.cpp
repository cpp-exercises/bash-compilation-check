/**
 * Reads two numbers from cin and writes their product to cout.
 */

#include <iostream>
#include <unistd.h>
using namespace std;

int main() {
    int* dummy;
    for (int i = 0 ; i<5 ; i ++)
        dummy = new int(i);
    return 0;
}

